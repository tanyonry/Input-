# Tasks

## Table Creation
- [x] Create HTML file with CSS-styled table
- [x] Verify the output